const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 10000;

app.use(bodyParser.json());
app.get('/', (req, res) => res.send('FeetFusion IA API active ✨'));

app.post('/api/generate', async (req, res) => {
  const prompt = req.body.prompt;
  if (!prompt) return res.status(400).json({ error: 'Prompt manquant.' });

  try {
    const response = await fetch('https://api.replicate.com/v1/predictions', {
      method: 'POST',
      headers: {
        'Authorization': `Token ${process.env.REPLICATE_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        version: "a9758cb8b288947e9de925d6d616e31ec1959c8b63c29359a83a5b6b48e4c8b3",
        input: { prompt }
      })
    });

    const data = await response.json();
    const output = data?.output?.[0] || data?.urls?.get || null;
    if (output) return res.json({ image: output });

    res.status(500).json({ error: 'Aucune image générée.' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => console.log(`✅ FeetFusion API opérationnelle sur http://localhost:${port}`));
